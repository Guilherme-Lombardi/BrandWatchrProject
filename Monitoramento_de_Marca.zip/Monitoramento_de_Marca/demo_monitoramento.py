from textblob import TextBlob
import csv

# 1. Função para analisar sentimento
def analisar_sentimento(frase):
    polaridade = TextBlob(frase).sentiment.polarity
    if polaridade > 0:
        return "positivo"
    elif polaridade < 0:
        return "negativo"
    else:
        return "neutro"

# 2. Simulação de coleta de dados (entradas)
dados_coletados = [
    "Adorei o novo produto da marca!",
    "Não gostei do atendimento.",
    "Serviço razoável, poderia melhorar.",
    "Experiência excelente, voltarei a comprar.",
]

# 3. Processamento dos dados coletados
resultados = []
for frase in dados_coletados:
    sentimento = analisar_sentimento(frase)
    resultados.append((frase, sentimento))
    print(f"Frase: \"{frase}\" → Sentimento: {sentimento}")

# 4. Geração de relatório em CSV
nome_arquivo = "relatorio_sentimentos.csv"
with open(nome_arquivo, mode="w", newline='', encoding="utf-8") as arquivo:
    writer = csv.writer(arquivo)
    writer.writerow(["Frase", "Sentimento"])
    for frase, sentimento in resultados:
        writer.writerow([frase, sentimento])

print(f"\n✅ Relatório gerado com sucesso: {nome_arquivo}")